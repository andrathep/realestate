<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: loginAgent.php");
    exit;
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
   
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
    
</head>
<body id="body2">
<div id="myNav" class="overlay">
    <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
    <div class="overlay-content">
        <a href="home.php">Home</a>
        <a href="about.php">About</a>
        <a href="account.php">Account</a>
    </div>
    </div>
<span style="font-size:30px;cursor:pointer; color:white" onclick="openNav()">&#9776; Menu</span>

<script>
function openNav() {
  document.getElementById("myNav").style.width = "100%";
}

function closeNav() {
  document.getElementById("myNav").style.width = "0%";
}
</script>
<ul>
    <div class="page-header page-content">
        <p2>Hi, <b><?php echo htmlspecialchars($_SESSION["fname"]); ?></b>. Welcome to our site.</p2>
    </div>
    <p>
        <a href="reset-password.php" class="btn btn-warning p">Reset Your Password</a>
        <a href="logout.php" class="btn btn-danger p">Sign Out of Your Account</a>
    </p>
</ul>
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <div id="div2" class="btnH from-top"><b>Clients</b></div>
    <div id="div2" class="btnH from-top"><b>Offers</b></div>
    <div id="div2" class="btnH from-top"><b>Portofolio</b></div>
    <div id="div2" class="btnH from-top"><b>Contact</b></div>

</body>
</html>