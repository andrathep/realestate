<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body {
            background-color: #9D858D;
            font-family: "Impact, Charcoal, sans-serif";
        }
        
        ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;
            background-color: #A2D9CE;
        }
        
        li {
            float: left;
        }
        
        li a,
        .dropbtn {
            display: block;
            color: white;
            text-align: center;
            padding: 24px 26px;
            text-decoration: none;
            font-size: large;
        }
        
        li a:hover:not(.active),
        .dropdown:hover .dropbtn {
            background-color: #1C2541;
        }
        
        .active {
            background-color: #227C9D;
        }
        
        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #A2D9CE;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
            z-index: 1;
        }
        
        .dropdown-content a {
            color: white;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
            text-align: left;
        }
        
        .dropdown-content a:hover {
            background-color: #227C9D;
        }
        
        .dropdown:hover .dropdown-content {
            display: block;
        }
        .overlay {
            height: 100%;
            width: 0;
            position: absolute;
            z-index: 1;
            top: 1000px;
            left: 0;
            background-color: rgb(0,0,0);
            background-color: rgba(0,0,0, 0.9);
            overflow-x: hidden;
            transition: 0.5s;
            }

        .overlay-content {
            position: relative;
            top: 25%;
            width: 100%;
            text-align: center;
            margin-top: 30px;
            }

        .overlay a {
            padding: 8px;
            text-decoration: none;
            font-size: 36px;
            color: #818181;
            display: block;
            transition: 0.3s;
            }

        .overlay a:hover, .overlay a:focus {
            color: #f1f1f1;
            }

        .overlay .closebtn {
            position: absolute;
            top: 20px;
            right: 45px;
            font-size: 60px;
            }

        @media screen and (max-height: 450px) {
        .overlay a {font-size: 20px}
        .overlay .closebtn {
            font-size: 40px;
            top: 15px;
            right: 35px;
            }
        }
    </style>
</head>

<body>

    <ul>
        <li><a class="active" href="home.php"><b>Home</b></a></li>
        <li><a href="about.php"><b>About</b></a></li>
        <li><a href="browse.php"><b>Browse</b></a></li>
        <li id= "account" class="overlay">
            <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
            <div class="overlay-content">
                <a href="#">About</a>
                <a href="#">Services</a>
                <a href="#">Clients</a>
                <a href="#">Contact</a>
            </div>
        </li>
        <li><a href="home.php" onclick="openNav()">&#9776;Account</a>
        </li>
        </ul>
        
        


<script>
function openNav() {
  document.getElementById("account").style.width = "100%";
}

function closeNav() {
  document.getElementById("account").style.width = "0%";
}
</script>
        

    
    
</body>


</html>

